String get name => 'spoke_c';
