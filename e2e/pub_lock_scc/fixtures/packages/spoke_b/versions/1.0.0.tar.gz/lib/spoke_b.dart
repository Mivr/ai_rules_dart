String get name => 'spoke_b';
